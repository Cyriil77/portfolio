import { gsap } from "gsap";
import { CSSRulePlugin } from "gsap/CSSRulePlugin";
import { EaselPlugin } from "gsap/EaselPlugin";
import { ScrollToPlugin } from "gsap/ScrollToPlugin";

gsap.registerPlugin(CSSRulePlugin, EaselPlugin, ScrollToPlugin);

const chevronDownHomePage = document.querySelectorAll('.chevron-down-scroll i')[0];
const destinationToScrollAboutMe = document.getElementById('ctnr-about-me');



chevronDownHomePage.addEventListener('click', (e) => {
    e.preventDefault()
    const topPos = destinationToScrollAboutMe.offsetTop - 80
    gsap.to(window, { duration: 0.5, scrollTo: { y: topPos } });
})