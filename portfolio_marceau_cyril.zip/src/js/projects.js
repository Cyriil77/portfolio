'use strict'

window.addEventListener('load', () => {

    if (window.innerWidth >= 1200) {
        
    }
});