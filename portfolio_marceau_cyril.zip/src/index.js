'use strict'

import './style/main.css';
import './style/mediaQueries.css'
import './js/menu.js';
import './js/typed.js';
import './js/scroll.js';
import './js/gsap.js'
import './js/projects.js'
import './lib/fit.fontawesome.js';



window.addEventListener("load", () => {

    // Home page add dynamically text
    const tel = document.querySelectorAll('a')[6];
    tel.href = 'tel:0617881934';

    const mail = document.querySelectorAll('a')[7];
    mail.href = 'mailto:marceau.cyril@hotmail.fr';

    // Lazy load picture user
    const lazyLoadElement = document.querySelectorAll('.lazy-load')

    for (const element of lazyLoadElement) {

        if (element.complete) {
            element.classList.add('loaded');
        }

        element.onload = () => {
            element.classList.add('loaded');
        }

    }

    // Delete text on iphone SE / 5
    if (window.innerWidth === 320) {
        const spanDeleteAboutMe = document.querySelector('.datas-about-me span');
        spanDeleteAboutMe.style.display = 'none';
    }


    // Project hover
    const projectLists = document.querySelectorAll('.ctnr-project')


    if (window.innerWidth >= 1200) {

        for (let i = 0; i < projectLists.length; i++) {

            let nextEl;
            let childrenDiv;

            // Select next div
            nextEl = projectLists[i + 1]

            // get children div -> title and explication - langages
            childrenDiv = projectLists[i].childNodes

            childrenDiv.forEach(element => {

                // Append on div picture
                const el = element
                nextEl.childNodes[1].appendChild(el)
                // console.log(element)

            });


            projectLists[i].addEventListener('mouseenter', (e) => {

                projectLists[i + 1].style.filter = 'grayscale(1)';

                // Get ctnr div
                const ctnrNewDiv = nextEl.childNodes[0]

                // Get new value who is append
                const childrenNewDiv = ctnrNewDiv.childNodes

                // Display It
                childrenNewDiv.forEach(element => {
                    element.style.display = 'block'
                    element.style.backgroundColor = 'red'
                });
            })


            projectLists[i].addEventListener('mouseleave', (e) => {

                projectLists[i + 1].style.filter = 'grayscale(0)';

                const ctnrNewDiv = nextEl.childNodes[0]
                const childrenNewDiv = a.childNodes

                childrenNewDiv.forEach(element => {
                    element.style.display = 'none'
                    element.style.backgroundColor = 'black'
                });

            })
        }
    }








});